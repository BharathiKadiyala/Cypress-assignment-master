import Navigation from '../support/navigation'
import LoginPage from '../support/pages/loginPage'
import RoomPage from '../support/pages/roomPage'
import BrandingPage from '../support/pages/brandingPage'
import ContactPage from '../support/pages/contactPage'
import * as testData from '../fixtures/account/common'

describe('Automation Testing Online tests', () => {
    const navigation = new Navigation();
    const login = new LoginPage();
    const roomPage = new RoomPage();
    const branding = new BrandingPage();
    
    beforeEach(()=>{
        cy.openHomePage();
        navigation.clickAdminPanel();
        login.executeLogin(testData.VALID_USERNAME,testData.VALID_PASSWORD);
        cy.wait(3000);
    })

    // Test one: Verity that you can log in with valid credentials
    it('should be able to login', () => {
        roomPage.validateRoomPages();
    })

   //Test two: Check to see if rooms are saved and displayed in the UI
    it('should be able to save rooms', () => {
        roomPage.executeCreateRoom(testData.ROOMNO,testData.ROOMPRICE);
        cy.wait(2000);
        roomPage.validateRoomDetails(1);
    })

    // Test three: Check to see the confirm message appears when branding is updated
    it('should be able to update branding', () => {
        navigation.navigateToBranding();
        cy.wait(2000);
        branding.executeUpdateBrand(testData.BRAND_NAME);
        cy.wait(1000);
        branding.verifyCloseButton();
    })

    // Test five: Check to see if unread messages are bolded
    it('should see unread messages are bolded', () => {
        navigation.navigateToMessage();
        cy.wait(2000);
        cy.get('div.read-false').its('length').should('be.at.least', 1);
    })
})

// Contact Form Automation Tests
describe('Automation Tests for Contact form ', () => {
    const navigation = new Navigation();
    const contact = new ContactPage();

    // Test four: Check to see if the contact form shows a success message
    it('should see success message', () => {
        navigation.navigateToContact();
        contact.executeContact(testData.CONTACT_NAME,testData.CONTACT_EMAIL,testData.CONTACT_PHONE,testData.CONTACT_SUBJECT,testData.CONTACT_MESSAGE);
        cy.wait(3000);
        contact.verifyThankMessage();
    })
})