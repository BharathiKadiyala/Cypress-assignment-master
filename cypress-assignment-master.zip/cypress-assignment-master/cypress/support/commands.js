Cypress.Commands.add('openHomePage',() =>{
    cy.visit('https://automationintesting.online/#/')
  })