/**LoginPage Test Data */
export const VALID_USERNAME = 'admin'
export const VALID_PASSWORD = 'password'

/**RoomPage Test Data */
export const ROOMNO= '101'
export const ROOMPRICE='101'

/**ContactPage Test Data */
export const CONTACT_NAME = 'TEST123'
export const CONTACT_EMAIL = 'TEST123@TEST.COM'
export const CONTACT_PHONE = '01212121311'
export const CONTACT_SUBJECT = 'TEsTEST'
export const CONTACT_MESSAGE = 'TEsTESTTEsTESTTEsTEST'

/**BrandPage Test Data */
export const BRAND_NAME = 'Test'
