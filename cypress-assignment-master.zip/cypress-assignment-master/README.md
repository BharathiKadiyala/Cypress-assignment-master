# Snappet.cypress-assignment

#QA Cypress Testing Assignment

## Introduction
This is an assignment for QA candidates

## Task

This assignment is about two things
1. Create meaningful, reproducible, reliable and non-flaky tests
2. Creating clean, readable and maintainable code. 

Below are five tests that (somehow) work but require cleaning up. Update this code to make it easier to maintain, more readable and has sensible ways of asserting data. You might want to research different approaches to improving UI automation such as Page Object Models.

 1. Verity that you can log in with valid credentials
 2. Check to see if rooms are saved and displayed in the UI
 3. Check to see the confirm message appears when branding is updated
 4. Check to see if the contact form shows a success message
 5. Check to see if unread messages are bolded


TypeScript is also installed and enabled, so if you are comfortable with it, please feel free to use the same.

## Steps

1. In the command line, install the package dependencies using the command `npm install`
2. Run the tests using the command `npm run cypress:open`. This brings the Cypress runner. You can now run the tests.
3. In your IDE or code editor of choice (we recommend VS Code but you are free to choose what you like most) edit the code and run it till you feel confident it is done.
4. Share results with us.

##Documentation about Automation Tests:

1. Used Page Object Model. A page object is a class that represents a page in the web application. Each page of the web application generally corresponds to one class in the page object. Following page objects are created in order to use them in the actual test cases under Supprt/pages folder:
    -->loginPage.ts
    -->contactPage.ts
    -->brnadingPage.ts
    -->roomPage.ts

These Page Objects contains the object/field locators and their corresponding functions (ex: getters and setters) which needs to be used in the actual test cases.

2. test.js is the file that contains actual test cases for the following scenarios:
         1. Verity that you can log in with valid credentials
         2. Check to see if rooms are saved and displayed in the UI
         3. Check to see the confirm message appears when branding is updated
         4. Check to see if the contact form shows a success message
         5. Check to see if unread messages are bolded

  There are 2 decribe blocks in test.js as scenarios 1,2,3, and 5 needs user login where as scenario 4 does not need user login. 
  
  For the scenarios where it needs user login, have written a beforeEach block which contains opening of HomePage, navigating to AdminPanel and login with Valid Username and Password. As the name suggests, this block executes before each 'it' (test case) inside this describe block.

  The 2nd decribe block is for Contact Form automation. It does not need user login. Hence, created a separate decribe block which has 'it' block inside it.

 3. For all these scenarios, the test data comes from fixtures folder. Test data file path is: fixtures/account/common.ts

 4. navigation.ts has created under Support which contains methods to navigate to different pages in the application. User can just call these methods by creating an object to this class. 
  



