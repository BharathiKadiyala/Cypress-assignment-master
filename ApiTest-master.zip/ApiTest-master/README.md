
Make sure you have the following Installed:

    1. Install nodejs 
    2. Install npm
    3. `npm install`
    4. `npm start`

The API will be up and running.

    You can view localhost:3000/pupils to get a list of all pupils or go to localhost:3000/pupils/{pupilId} to get only specific pupil

    You can also do POST to /pupils and DELETE to /pupils/{pupilId}, which requires Basic Authentication header to be present in the request  

    `username: testCandidate`  
    `password: P@ssw0rd`

Documentation about API Automation Tests:

1. Have used Data Driven Framework concepts using Fixtures. The file "example.json" under 'fixtures' folder contains pupil data that needs to be POSTed to API, GET the details, and then finally DELETE the same pupil data. 
2. Along with "example.json", there is another file "constants.js" under fixtures/testdataConstants folder. This contains the typical constant values like URL, UserName and PassWord that are being used by test cases to hit the URL and for authentication purposes. These contants can be directly accessed by using importing the file as testData 
3. testPupilAPI.js is the file which contains actual tests that test POST, GET, and DELETE API Requests. In this file, there is a "beforeEach" block which runs before every test case. This gets the test data from "example.json" under "fixtures"
4. testPupilAPI.js contains 4 "it" blocks (4 test cases) for Status check, POST Pupil data, GET Pupil data and DELETE Pupil data. 
5. For POST and DELETE requests, user authentication is needed, hence passing the UserName and Password in request along with URL and Method. Apart from these 3 (URL, Auth and Method), POST method needs body (test data from example.json to create a new Pupil) as well. So here, I have wrapped everything into options and passing that as a parameter to Request.
6. To run the tests, run these commands from Terminal: npm install (installs all necessary packages), npm start (API will be up and running), npx cypress open (opens Test Runner to execute Cypress Tests)