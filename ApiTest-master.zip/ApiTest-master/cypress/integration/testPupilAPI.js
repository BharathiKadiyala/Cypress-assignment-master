import * as testData from '../fixtures/testdataConstants/constants';

//<reference types="Cypress" />
describe('Testing API Endpoints Using Cypress', function()  {    
    
    let  PupilID;
    beforeEach(function(){
        cy.fixture('example').then(function(data)
        {
            this.data = data;
        })
    })

   it('Status check', function() {  
        cy.request(testData.PUPILURL).then((response) => {
        expect(response.status).equal(200)
        expect(response.body[0].firstName).equal("Newmcuser")
       });
    })

    //Creation of New user by using POST
   it('POST Request', function()  {
     const options = {
        url: testData.PUPILURL,
        method: 'POST',
        auth: {
            username: testData.VALID_USERNAME,
            password: testData.VALID_PASSWORD,
        },
        body: {
            classId: this.data.classId,
            email: this.data.email,
            firstName: this.data.firstName,
            gradeId: this.data.gradeId,
            infix: this.data.infix,
            isDisabled: this.data.isDisabled,
            lastName: this.data.lastName,
          },   
        };
        cy.request(options).then((response) => {      
            expect(response.status).equal(201)    
            expect(response.body, 'response body').to.deep.includes({
            firstName: this.data.firstName,
            infix: this.data.infix,
            lastName: this.data.lastName,
            classId: this.data.classId,
            gradeId: this.data.gradeId,
            email: this.data.email,
            isDisabled:this.data.isDisabled
        })
            const body = (response.body)
            PupilID = body['pupilId']     
            cy.log("New Pupil ID is: "+PupilID);                        
        })
     })
    
    //Get Pupil record by using GET
    it('GET Request', function()  {
        cy.request(testData.PUPILURL+PupilID)
            .then((response) => {
                   expect(response.status).equal(200);               
                // expect(response.body).to.have.property("firstName", this.data.firstName); 
                   expect(response.body.firstName).equal(this.data.firstName);
                   expect(response.body.lastName).equal(this.data.lastName);
                   expect(response.body.email).equal(this.data.email);
                   expect(response.body.gradeId).equal(this.data.gradeId);
                   expect(response.body.isDisabled).equal(this.data.isDisabled);
                   expect(response.body.infix).equal(this.data.infix);
                   expect(response.body.classId).equal(this.data.classId);
            })
    })

    //Delete Pupil record 
    it("DELETE Request", function() {
          cy.request({
                    method : 'DELETE',
                    url: testData.PUPILURL+PupilID,
                    auth: {
                        username: testData.VALID_USERNAME,
                        password: testData.VALID_PASSWORD
                      }
                    }).then((response) => {
                      expect(response.status).equal(204);
                      expect(response.body).to.be.empty;
                    cy.log("Deleted Pupil ID is: "+PupilID);
          })	
    })
})