export const VALID_USERNAME = 'testCandidate'
export const VALID_PASSWORD = 'P@ssw0rd'
export const PUPILURL = 'http://localhost:3000/pupils/'